
public class pattern15 {
	public static void main(String[] args) {
		
	}
}
