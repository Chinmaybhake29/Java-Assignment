package patternprinting;

public class Pattern12 {

//	public static void main(String[] args) {
//		for(int i=1;i<5;i++)
//		{
//			for(int j=5;j>i;j--)
//			{
//				System.out.print("  ");
//			}
//			for(int j=1;j<=i;j++)
//			{
//				System.out.print(""+(j+i-1)+"   ");
//			}
//			System.out.println();
//		}
//
//	}

	public static void main(String[] args) {
		int num=5;
		for (int i = 1; i <= 5; i++) {
			
			for (int j = 5; j >= i; j--) {
				System.out.print(num);
			}
			num--;
			System.out.println();
		}
	}

}
