package Assignment3;

public class Door {

	private int validID;
	
}
