package Assignment6;

import java.util.Scanner;

public class valid 
{
     private int n;
     
     Scanner sc=new Scanner(System.in);
     
     public void accept()
     {
    	 System.out.println("Enter the number");
    	 n=sc.nextInt();
     }
     public void check()
     {
    	 if(n>=10 && n<=20)
    		 System.out.println(n + " is availabel in range number");
    	 else if(n!=20)
    		 System.out.println(n + " is not availabel in range");
     }
}
