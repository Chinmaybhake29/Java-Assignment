package Assignment6;

public class num {

	public static void main(String[] args) {
		valid v=new valid();
		v.accept();
		v.check();

	}

}
