package Assignment1;

public class Person 
{
  public static void main(String args[])
  {
	  loan loan = new loan();  
      loan.accept();  
      loan.checkEligibility();  
      loan.display();  
  }
}
