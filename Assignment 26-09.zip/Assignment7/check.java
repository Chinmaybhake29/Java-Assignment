package Assignment7;

public class check {

	public static void main(String[] args) {
           Weather w=new Weather();
           w.accept();
           w.chaecktemprature();
	}

}
