package Assignment7;

import java.util.Scanner;

public class Weather 
{
	private int temprature;
	
	Scanner sc=new Scanner(System.in);
	
	public void accept()
	{
		System.out.println("Enter the temprature");
		temprature=sc.nextInt();
	}
	public void chaecktemprature()

	{
		if( temprature >=20 && temprature <=30)
			System.out.println(temprature + " is a safe to go outside");
		else if (temprature!=34)
			System.out.println(temprature + " sorry avoid to go outside");
	}
}
