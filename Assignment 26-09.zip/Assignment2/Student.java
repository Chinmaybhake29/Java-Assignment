package Assignment2;

public class Student {

	public static void main(String[] args) {
	   Grade g=new Grade();
	   g.accept();
	   g.checkResult();
	   g.display();

	}

}
