package Assignment4;

public class Person {
	public static void main(String args[])
	{
		Eligibility e=new Eligibility();
		e.accept();
		e.checkEligibilty();
		e.display();
	}
}
